import { Authenticated, Unauthenticated } from "convex/react";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <header className="sticky top-0 z-10 bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 h-16 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">The Rxzaver</h2>
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8">
        <Content />
      </main>
      
      <Toaster />
    </div>
  );
}

function Content() {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-6xl font-bold text-white mb-4">
            The Rxzaver
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Join our thriving Discord community with over 2K+ members and 500K+ messages!
            Connect, chat, and have fun with fellow members since 2021.
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-6 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-3xl font-bold text-white">2K+</div>
            <div className="text-gray-300">Members</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-3xl font-bold text-white">500K+</div>
            <div className="text-gray-300">Messages</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-3xl font-bold text-white">2021</div>
            <div className="text-gray-300">Est. Year</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="text-3xl font-bold text-white">Level 1</div>
            <div className="text-gray-300">Boost Level</div>
          </div>
        </div>

        <a 
          href="https://discord.gg/h4EcW8CB4s" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-8 py-4 rounded-lg transition-colors shadow-lg hover:shadow-xl"
        >
          <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
          </svg>
          Join The Rxzaver Discord
        </a>
      </section>

      {/* Rules Section */}
      <section className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-white text-center mb-8">Server Rules</h2>
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
          <div className="grid gap-6">
            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">1</div>
              <div>
                <h3 className="text-white font-semibold mb-2">Age Requirement</h3>
                <p className="text-gray-300">You must be 13 years or older to participate in this server.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">2</div>
              <div>
                <h3 className="text-white font-semibold mb-2">English Only</h3>
                <p className="text-gray-300">Please communicate in English only to ensure everyone can understand and participate.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">3</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Spamming or Mass Pinging</h3>
                <p className="text-gray-300">Avoid spamming messages or pinging @everyone/@here unnecessarily.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">4</div>
              <div>
                <h3 className="text-white font-semibold mb-2">Be Respectful</h3>
                <p className="text-gray-300">Treat all members with respect and kindness. Harassment and toxicity will not be tolerated.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">5</div>
              <div>
                <h3 className="text-white font-semibold mb-2">Use Appropriate Channels</h3>
                <p className="text-gray-300">Please use the correct channels for your conversations and keep discussions on-topic.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">6</div>
              <div>
                <h3 className="text-white font-semibold mb-2">Limited Profanity</h3>
                <p className="text-gray-300">Swearing is allowed but please keep it to a reasonable limit and avoid excessive use.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">7</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No NSFW Content</h3>
                <p className="text-gray-300">Keep all content appropriate and family-friendly. No NSFW material is allowed.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">8</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Discrimination</h3>
                <p className="text-gray-300">Racism, sexism, homophobia, and any form of discrimination are strictly prohibited.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">9</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Political/World Event Discussions</h3>
                <p className="text-gray-300">Please avoid discussions about current world events and political topics to maintain a peaceful environment.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">10</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Begging</h3>
                <p className="text-gray-300">Please don't beg for items, money, or special privileges from other members.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">11</div>
              <div>
                <h3 className="text-white font-semibold mb-2">Don't Ping Rxzav</h3>
                <p className="text-gray-300">Please avoid unnecessarily pinging Rxzav unless it's truly important.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">12</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Self-Promotion</h3>
                <p className="text-gray-300">Self-advertisement and promotion of personal content/servers is not allowed without permission.</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-indigo-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm flex-shrink-0">13</div>
              <div>
                <h3 className="text-white font-semibold mb-2">No Suspicious Links</h3>
                <p className="text-gray-300">Don't share offsite links or suspicious URLs that could be harmful or lead to external sites.</p>
              </div>
            </div>
          </div>

          <div className="mt-8 p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
            <p className="text-yellow-200 text-sm">
              <strong>Note:</strong> Breaking these rules may result in warnings, temporary mutes, or permanent bans depending on the severity. 
              Moderators have the final say in all decisions.
            </p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-white mb-8">About Our Community</h2>
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
          <p className="text-gray-300 text-lg leading-relaxed mb-6">
            The Rxzaver Discord server has been bringing people together since 2021. With over 2,000 members and 
            more than 500,000 messages exchanged, we've built a vibrant community where everyone can feel welcome.
          </p>
          <p className="text-gray-300 text-lg leading-relaxed">
            Our server features various channels for different interests, active moderation to ensure a safe environment, 
            and regular community events. Join us today and become part of our growing family!
          </p>
        </div>
      </section>

      {/* Auth Section */}
      <section className="max-w-md mx-auto">
        <Unauthenticated>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
            <h3 className="text-2xl font-bold text-white text-center mb-6">Admin Access</h3>
            <SignInForm />
          </div>
        </Unauthenticated>
        
        <Authenticated>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">Welcome, Admin!</h3>
            <p className="text-gray-300 mb-6">You have administrative access to manage the server website.</p>
          </div>
        </Authenticated>
      </section>
    </div>
  );
}
